// ─────────────────────────────────────────────────────────────
// Beneplus — Logo directions
// ─────────────────────────────────────────────────────────────
// All marks share a consistent set of brand colors; each logo
// picks from the palette. Type uses three families:
//   • Geist          — modern geometric sans
//   • Plus Jakarta   — humanist warm sans
//   • Fraunces       — editorial serif (used sparingly)
//
// Palette
const BP = {
  ink:    '#0E1F1C',  // deep forest ink
  bone:   '#F4EFE6',  // warm off-white
  cream:  '#FAF7F0',
  moss:   '#1E5C4F',  // primary green
  leaf:   '#2E7D6A',
  sage:   '#9BB5A3',
  coral:  '#E8714A',  // accent
  butter: '#F2C94C',
  sky:    '#4A7FB8',
  plum:   '#3D2C4A',
};

// ─────────────────────────────────────────────────────────────
// Shared artboard chrome — every logo lives on a generous
// padded canvas with a tiny corner label.
// ─────────────────────────────────────────────────────────────
function Plate({ bg = BP.bone, fg = BP.ink, note, children, padding = 0 }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', overflow: 'hidden', padding,
      fontFamily: '"Plus Jakarta Sans", system-ui, sans-serif',
    }}>
      {children}
      {note && (
        <div style={{
          position: 'absolute', left: 18, bottom: 14,
          fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
          opacity: 0.5, fontWeight: 600,
        }}>{note}</div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 01 · bene+   (lowercase wordmark, accent plus)
// ═════════════════════════════════════════════════════════════
function Logo01({ scale = 1, mono = false }) {
  const plus = mono ? 'currentColor' : BP.coral;
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontWeight: 600, letterSpacing: '-0.045em',
      fontSize: 120 * scale, lineHeight: 1,
      display: 'flex', alignItems: 'baseline', gap: 0,
    }}>
      <span>bene</span>
      <span style={{
        color: plus, fontWeight: 500,
        fontSize: 130 * scale, marginLeft: 6 * scale,
        transform: `translateY(${-6 * scale}px)`,
        display: 'inline-block',
      }}>+</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 02 · Beneplus  (Bene · plus split, with plus glyph)
// ═════════════════════════════════════════════════════════════
function Logo02({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: '"Plus Jakarta Sans", system-ui, sans-serif',
      fontSize: 72 * scale, lineHeight: 1, letterSpacing: '-0.03em',
      display: 'flex', alignItems: 'center', gap: 14 * scale,
    }}>
      <span style={{ fontWeight: 700, color: BP.ink }}>Bene</span>
      <span style={{
        width: 24 * scale, height: 24 * scale, position: 'relative',
        display: 'inline-block',
      }}>
        <span style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 24 * scale, height: 6 * scale, background: BP.moss, borderRadius: 1,
          top: '50%', transform: 'translateY(-50%)',
        }} />
        <span style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 6 * scale, height: 24 * scale, background: BP.moss, borderRadius: 1,
          left: '50%', transform: 'translateX(-50%)',
        }} />
      </span>
      <span style={{ fontWeight: 400, color: BP.moss }}>plus</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 03 · B+ Monogram — solid tile, plus carved in negative space
// ═════════════════════════════════════════════════════════════
function Logo03({ scale = 1, withWordmark = true }) {
  const S = 140 * scale;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 22 * scale }}>
      <div style={{
        width: S, height: S, background: BP.moss, borderRadius: S * 0.22,
        position: 'relative', overflow: 'hidden',
        boxShadow: '0 1px 0 rgba(255,255,255,0.04) inset',
      }}>
        {/* B */}
        <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
          <text x="50" y="78" textAnchor="middle"
            fontFamily="Geist, system-ui, sans-serif"
            fontWeight="700" fontSize="92"
            letterSpacing="-0.04em"
            fill={BP.cream}>B</text>
          {/* plus carved bottom-right */}
          <g transform="translate(74,74)">
            <circle r="14" fill={BP.coral} />
            <rect x="-7" y="-1.6" width="14" height="3.2" fill={BP.cream} rx="0.5" />
            <rect x="-1.6" y="-7" width="3.2" height="14" fill={BP.cream} rx="0.5" />
          </g>
        </svg>
      </div>
      {withWordmark && (
        <div style={{
          fontFamily: 'Geist, system-ui, sans-serif',
          fontSize: 52 * scale, fontWeight: 600,
          letterSpacing: '-0.035em', color: BP.ink, lineHeight: 1,
        }}>
          Beneplus
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 04 · Petal mark — soft 4-petal plus + wordmark
// ═════════════════════════════════════════════════════════════
function PetalMark({ size = 96, color = BP.leaf, accent = BP.butter }) {
  // 4 rounded petals = friendly plus / wellness blossom
  return (
    <svg viewBox="-50 -50 100 100" width={size} height={size}>
      {[0, 90, 180, 270].map((r) => (
        <rect key={r} x="-12" y="-44" width="24" height="44"
          rx="12" fill={color} transform={`rotate(${r})`} />
      ))}
      <circle r="9" fill={accent} />
    </svg>
  );
}
function Logo04({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 20 * scale }}>
      <PetalMark size={108 * scale} />
      <div style={{
        fontFamily: '"Plus Jakarta Sans", system-ui, sans-serif',
        fontSize: 64 * scale, fontWeight: 600,
        letterSpacing: '-0.035em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 05 · Stencil B — counters become plus shapes
// ═════════════════════════════════════════════════════════════
function StencilB({ size = 140, color = BP.ink }) {
  // Custom B drawn so the two counters are plus-shaped cutouts
  const W = size, H = size;
  return (
    <svg viewBox="0 0 100 100" width={W} height={H}>
      <defs>
        <mask id="bp-stencil-b">
          <rect width="100" height="100" fill="white" />
          {/* Upper plus counter */}
          <g transform="translate(54,33)">
            <rect x="-13" y="-3.5" width="26" height="7" rx="1" fill="black" />
            <rect x="-3.5" y="-13" width="7" height="26" rx="1" fill="black" />
          </g>
          {/* Lower plus counter */}
          <g transform="translate(54,67)">
            <rect x="-14" y="-3.5" width="28" height="7" rx="1" fill="black" />
            <rect x="-3.5" y="-14" width="7" height="28" rx="1" fill="black" />
          </g>
        </mask>
      </defs>
      {/* Solid B silhouette */}
      <path d="
        M 18 12
        L 56 12
        C 74 12 82 22 82 33
        C 82 41 78 47 71 50
        C 80 52 86 60 86 70
        C 86 82 76 90 58 90
        L 18 90 Z"
        fill={color} mask="url(#bp-stencil-b)" />
    </svg>
  );
}
function Logo05({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 22 * scale }}>
      <StencilB size={130 * scale} color={BP.moss} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 56 * scale, fontWeight: 500,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 06 · Editorial serif stack — premium
// ═════════════════════════════════════════════════════════════
function Logo06({ scale = 1 }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
      lineHeight: 0.92, gap: 4 * scale,
    }}>
      <div style={{
        fontFamily: 'Fraunces, "Times New Roman", serif',
        fontSize: 92 * scale, fontWeight: 400,
        fontStyle: 'italic',
        fontVariationSettings: '"opsz" 144, "SOFT" 50',
        letterSpacing: '-0.03em', color: BP.ink,
      }}>
        Bene
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10 * scale,
      }}>
        <span style={{
          display: 'inline-block', width: 18 * scale, height: 18 * scale,
          position: 'relative',
        }}>
          <span style={{
            position: 'absolute', inset: 0, margin: 'auto',
            width: 18 * scale, height: 3 * scale, background: BP.coral,
            top: '50%', transform: 'translateY(-50%)',
          }} />
          <span style={{
            position: 'absolute', inset: 0, margin: 'auto',
            width: 3 * scale, height: 18 * scale, background: BP.coral,
            left: '50%', transform: 'translateX(-50%)',
          }} />
        </span>
        <span style={{
          fontFamily: 'Geist, system-ui, sans-serif',
          fontSize: 26 * scale, letterSpacing: '0.36em',
          textTransform: 'uppercase', fontWeight: 500, color: BP.ink,
          paddingTop: 2 * scale,
        }}>plus</span>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 07 · Circle badge / seal
// ═════════════════════════════════════════════════════════════
function Logo07({ scale = 1 }) {
  const S = 200 * scale;
  return (
    <div style={{
      width: S, height: S, borderRadius: '50%',
      background: BP.ink, color: BP.cream,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative',
    }}>
      {/* outer rotating ring text via SVG */}
      <svg viewBox="0 0 200 200" width={S} height={S} style={{ position: 'absolute', inset: 0 }}>
        <defs>
          <path id="bp-ring" d="M 100,100 m -82,0 a 82,82 0 1,1 164,0 a 82,82 0 1,1 -164,0" />
        </defs>
        <text fill={BP.sage} fontFamily="Geist, system-ui, sans-serif"
          fontSize="11" letterSpacing="6" fontWeight="500">
          <textPath href="#bp-ring" startOffset="0">
            BENEPLUS · EST · MMXXVI · CARE COMPOUNDS ·
          </textPath>
        </text>
      </svg>
      <div style={{
        textAlign: 'center', lineHeight: 0.95,
        fontFamily: 'Geist, system-ui, sans-serif',
      }}>
        <div style={{
          fontSize: 38 * scale, fontWeight: 600, letterSpacing: '-0.04em',
        }}>Bene</div>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          gap: 6 * scale, marginTop: 4 * scale,
        }}>
          <span style={{
            display: 'inline-block', width: 14 * scale, height: 14 * scale,
            position: 'relative',
          }}>
            <span style={{
              position: 'absolute', inset: 0, margin: 'auto',
              width: 14 * scale, height: 2.5 * scale, background: BP.coral,
              top: '50%', transform: 'translateY(-50%)',
            }} />
            <span style={{
              position: 'absolute', inset: 0, margin: 'auto',
              width: 2.5 * scale, height: 14 * scale, background: BP.coral,
              left: '50%', transform: 'translateX(-50%)',
            }} />
          </span>
          <span style={{
            fontSize: 16 * scale, letterSpacing: '0.32em',
            textTransform: 'uppercase', color: BP.sage, fontWeight: 500,
          }}>plus</span>
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 08 · Ligature wordmark — custom "Beneplus" with the
//    crossbar of 'e' extending into the plus.
// ═════════════════════════════════════════════════════════════
function Logo08({ scale = 1 }) {
  // Set in Geist; the dot of the 'i' is removed by treating 'plus'
  // as 'plu+' visually — last letter 's' replaced by stylized +.
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontWeight: 700, letterSpacing: '-0.05em',
      fontSize: 96 * scale, color: BP.ink, lineHeight: 1,
      display: 'flex', alignItems: 'center',
    }}>
      <span>Beneplu</span>
      <span style={{
        display: 'inline-block',
        width: 64 * scale, height: 64 * scale,
        position: 'relative', marginLeft: 4 * scale,
        transform: `translateY(${4 * scale}px)`,
      }}>
        <span style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 64 * scale, height: 14 * scale, background: BP.coral, borderRadius: 2,
          top: '50%', transform: 'translateY(-50%)',
        }} />
        <span style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 14 * scale, height: 64 * scale, background: BP.coral, borderRadius: 2,
          left: '50%', transform: 'translateX(-50%)',
        }} />
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// App-icon tiles
// ─────────────────────────────────────────────────────────────
function AppTile({ bg, children, radius = 56 }) {
  return (
    <div style={{
      width: 240, height: 240, borderRadius: radius, background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 24px 48px -24px rgba(14,31,28,0.35), 0 2px 4px rgba(14,31,28,0.08)',
      position: 'relative', overflow: 'hidden',
    }}>
      {children}
    </div>
  );
}

function Icon01() { // bene+ mark
  return (
    <AppTile bg={BP.cream}>
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontWeight: 600, letterSpacing: '-0.05em',
        fontSize: 130, color: BP.ink, lineHeight: 1,
        display: 'flex', alignItems: 'baseline',
      }}>
        b<span style={{ color: BP.coral, marginLeft: 4, fontWeight: 500, fontSize: 140, transform: 'translateY(-8px)', display: 'inline-block' }}>+</span>
      </div>
    </AppTile>
  );
}
function Icon02() { // monogram tile
  return (
    <AppTile bg={BP.moss}>
      <svg viewBox="0 0 100 100" width="240" height="240">
        <text x="50" y="78" textAnchor="middle"
          fontFamily="Geist, system-ui, sans-serif"
          fontWeight="700" fontSize="92" letterSpacing="-0.04em"
          fill={BP.cream}>B</text>
        <g transform="translate(74,74)">
          <circle r="14" fill={BP.coral} />
          <rect x="-7" y="-1.6" width="14" height="3.2" fill={BP.cream} rx="0.5" />
          <rect x="-1.6" y="-7" width="3.2" height="14" fill={BP.cream} rx="0.5" />
        </g>
      </svg>
    </AppTile>
  );
}
function Icon03() { // petal
  return (
    <AppTile bg={BP.bone}>
      <PetalMark size={150} color={BP.leaf} accent={BP.butter} />
    </AppTile>
  );
}
function Icon04() { // big plus
  return (
    <AppTile bg={BP.coral}>
      <div style={{ width: 130, height: 130, position: 'relative' }}>
        <div style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 130, height: 28, background: BP.cream, borderRadius: 4,
          top: '50%', transform: 'translateY(-50%)',
        }} />
        <div style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 28, height: 130, background: BP.cream, borderRadius: 4,
          left: '50%', transform: 'translateX(-50%)',
        }} />
      </div>
    </AppTile>
  );
}

// ─────────────────────────────────────────────────────────────
// Business card lockup
// ─────────────────────────────────────────────────────────────
function BizCard({ variant = 'moss' }) {
  const palettes = {
    moss:  { bg: BP.moss, fg: BP.cream, accent: BP.coral, sub: BP.sage },
    bone:  { bg: BP.bone, fg: BP.ink,   accent: BP.moss,  sub: '#7a8a82' },
    ink:   { bg: BP.ink,  fg: BP.cream, accent: BP.butter, sub: BP.sage },
  };
  const p = palettes[variant];
  return (
    <div style={{
      width: 520, height: 320, background: p.bg, color: p.fg,
      borderRadius: 16, padding: 36, position: 'relative',
      fontFamily: '"Plus Jakarta Sans", system-ui, sans-serif',
      boxShadow: '0 30px 60px -30px rgba(14,31,28,0.45), 0 4px 8px rgba(14,31,28,0.1)',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      overflow: 'hidden',
    }}>
      {/* top: mini logo */}
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 32, fontWeight: 600, letterSpacing: '-0.04em',
        display: 'flex', alignItems: 'baseline',
      }}>
        bene<span style={{ color: p.accent, fontSize: 36, marginLeft: 2, transform: 'translateY(-3px)', display: 'inline-block', fontWeight: 500 }}>+</span>
      </div>

      {/* contact */}
      <div style={{ lineHeight: 1.4 }}>
        <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>Mira Tanaka</div>
        <div style={{ fontSize: 13, color: p.sub, marginTop: 2 }}>Head of Member Care</div>
        <div style={{ fontSize: 12, color: p.sub, marginTop: 14, letterSpacing: '0.02em' }}>
          mira@beneplus.co · +1 415 555 0117
        </div>
      </div>

      {/* corner plus */}
      <div style={{
        position: 'absolute', right: -20, bottom: -20,
        width: 110, height: 110, opacity: 0.22,
      }}>
        <div style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 110, height: 16, background: p.accent,
          top: '50%', transform: 'translateY(-50%)',
        }} />
        <div style={{
          position: 'absolute', inset: 0, margin: 'auto',
          width: 16, height: 110, background: p.accent,
          left: '50%', transform: 'translateX(-50%)',
        }} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// In-context: website nav + hero teaser
// ─────────────────────────────────────────────────────────────
function WebHero() {
  return (
    <div style={{
      width: 880, height: 480, background: BP.bone, borderRadius: 16,
      overflow: 'hidden', position: 'relative',
      fontFamily: '"Plus Jakarta Sans", system-ui, sans-serif',
      boxShadow: '0 30px 60px -30px rgba(14,31,28,0.4)',
    }}>
      {/* top bar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 32px', borderBottom: `1px solid ${BP.sage}33`,
      }}>
        <div style={{
          fontFamily: 'Geist, system-ui, sans-serif',
          fontSize: 24, fontWeight: 600, letterSpacing: '-0.04em',
          display: 'flex', alignItems: 'baseline', color: BP.ink,
        }}>
          bene<span style={{ color: BP.coral, fontWeight: 500, fontSize: 26, marginLeft: 2, transform: 'translateY(-2px)', display: 'inline-block' }}>+</span>
        </div>
        <div style={{
          display: 'flex', gap: 28, fontSize: 13, color: BP.ink, fontWeight: 500,
        }}>
          <span>Benefits</span><span>For teams</span><span>Pricing</span><span>About</span>
        </div>
        <div style={{
          padding: '8px 16px', borderRadius: 999, background: BP.ink, color: BP.cream,
          fontSize: 13, fontWeight: 600,
        }}>Get started</div>
      </div>
      {/* hero */}
      <div style={{ padding: '56px 48px', display: 'flex', gap: 48 }}>
        <div style={{ flex: 1.2 }}>
          <div style={{
            fontSize: 12, letterSpacing: '0.24em', textTransform: 'uppercase',
            color: BP.moss, fontWeight: 600, marginBottom: 16,
          }}>Better benefits, by design</div>
          <h1 style={{
            fontFamily: 'Fraunces, serif',
            fontSize: 56, lineHeight: 1.02, fontWeight: 400, fontStyle: 'italic',
            letterSpacing: '-0.025em', color: BP.ink, margin: 0,
          }}>The everyday<br/>care platform.</h1>
          <p style={{
            fontSize: 15, color: '#3a4a45', maxWidth: 360, marginTop: 20, lineHeight: 1.55,
          }}>One simple place for your team's health, family, and financial benefits — with a human on the other end.</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
            <div style={{ padding: '12px 22px', borderRadius: 999, background: BP.moss, color: BP.cream, fontSize: 14, fontWeight: 600 }}>Book a demo</div>
            <div style={{ padding: '12px 22px', borderRadius: 999, border: `1px solid ${BP.ink}33`, fontSize: 14, fontWeight: 600, color: BP.ink }}>See how it works</div>
          </div>
        </div>
        <div style={{
          flex: 1, background: BP.moss, borderRadius: 18, position: 'relative',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <PetalMark size={180} color={BP.cream} accent={BP.coral} />
          <div style={{
            position: 'absolute', left: 24, bottom: 20, color: BP.cream, opacity: 0.8,
            fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600,
          }}>care, compounded</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  BP, Plate,
  Logo01, Logo02, Logo03, Logo04, Logo05, Logo06, Logo07, Logo08,
  Icon01, Icon02, Icon03, Icon04,
  PetalMark, BizCard, WebHero,
});
