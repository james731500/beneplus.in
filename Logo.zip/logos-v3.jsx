// ─────────────────────────────────────────────────────────────
// Beneplus — Logo directions (software development company)
// ─────────────────────────────────────────────────────────────
// Visual language drawn from source code: curly braces, JSX
// tags, terminal prompts, function syntax, comments. Every mark
// should make the viewer think "they ship software."
// Typography is monospace-first.

const BP = {
  ink:     '#0D1117',   // GitHub dark base
  ink2:    '#161B22',
  paper:   '#F2F4F8',
  paper2:  '#E5E8F0',
  indigo:  '#5B7CFF',   // primary brand
  violet:  '#A78BFA',   // syntax keyword
  mint:    '#3FD8AF',   // syntax string / terminal
  amber:   '#FFB454',   // syntax function
  pink:    '#F472B6',
  cyan:    '#67E8F9',
  gray:    '#6E7681',
  gridline:'#1F2937',
};

const MONO = '"Geist Mono", "JetBrains Mono", ui-monospace, monospace';
const SANS = 'Geist, system-ui, sans-serif';

// ─────────────────────────────────────────────────────────────
// Plate — generous padded canvas with a tiny corner label
// ─────────────────────────────────────────────────────────────
function Plate({ bg = BP.paper, fg = BP.ink, note, children, padding = 0, gridded = false }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', overflow: 'hidden', padding,
      fontFamily: SANS,
    }}>
      {gridded && (
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(${bg === BP.ink ? BP.gridline : BP.paper2} 1px, transparent 1px), linear-gradient(90deg, ${bg === BP.ink ? BP.gridline : BP.paper2} 1px, transparent 1px)`,
          backgroundSize: '32px 32px',
          maskImage: 'radial-gradient(ellipse at center, black 35%, transparent 78%)',
          WebkitMaskImage: 'radial-gradient(ellipse at center, black 35%, transparent 78%)',
          opacity: 0.7,
        }} />
      )}
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
      {note && (
        <div style={{
          position: 'absolute', left: 18, bottom: 14, zIndex: 2,
          fontFamily: MONO,
          fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase',
          opacity: 0.55, fontWeight: 500,
        }}>{note}</div>
      )}
    </div>
  );
}

// Square plus glyph
function PlusGlyph({ size = 24, thickness = 6, color = BP.indigo, radius = 0 }) {
  return (
    <span style={{
      display: 'inline-block', position: 'relative',
      width: size, height: size, flexShrink: 0,
    }}>
      <span style={{
        position: 'absolute', left: 0, right: 0, top: '50%',
        height: thickness, transform: 'translateY(-50%)',
        background: color, borderRadius: radius,
      }} />
      <span style={{
        position: 'absolute', top: 0, bottom: 0, left: '50%',
        width: thickness, transform: 'translateX(-50%)',
        background: color, borderRadius: radius,
      }} />
    </span>
  );
}

// Blinking caret/cursor block (reusable)
function Caret({ width = 18, height = 50, color = BP.indigo, speed = 1.05 }) {
  return (
    <>
      <style>{`
        @keyframes bp-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0.15; } }
      `}</style>
      <span style={{
        display: 'inline-block', width, height, background: color,
        animation: `bp-blink ${speed}s steps(1, end) infinite`,
        verticalAlign: 'baseline',
      }} />
    </>
  );
}

// ═════════════════════════════════════════════════════════════
// 01 · {Beneplus}   — curly-brace wordmark   (SIGNATURE)
// ═════════════════════════════════════════════════════════════
function Logo01({ scale = 1, fg = BP.ink, braceColor = BP.indigo }) {
  return (
    <div style={{
      fontFamily: MONO, fontSize: 96 * scale, lineHeight: 1,
      letterSpacing: '-0.04em', display: 'flex', alignItems: 'center',
      gap: 8 * scale, color: fg, fontWeight: 600,
    }}>
      <span style={{ color: braceColor, fontWeight: 400, fontSize: 110 * scale }}>{'{'}</span>
      <span>Beneplus</span>
      <span style={{ color: braceColor, fontWeight: 400, fontSize: 110 * scale }}>{'}'}</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 02 · </beneplus>   — JSX closing tag wordmark
// ═════════════════════════════════════════════════════════════
function Logo02({ scale = 1, fg = BP.ink }) {
  return (
    <div style={{
      fontFamily: MONO, fontSize: 72 * scale, lineHeight: 1,
      letterSpacing: '-0.02em', display: 'flex', alignItems: 'center',
      color: fg, fontWeight: 500,
    }}>
      <span style={{ color: BP.gray }}>&lt;/</span>
      <span style={{ fontWeight: 600 }}>bene</span>
      <PlusGlyph size={28 * scale} thickness={7 * scale} color={BP.indigo} radius={1} />
      <span style={{ fontWeight: 600, marginLeft: 2 * scale }}>plus</span>
      <span style={{ color: BP.gray }}>&gt;</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 03 · $ beneplus_   — terminal prompt with blinking caret
// ═════════════════════════════════════════════════════════════
function Logo03({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: MONO, fontSize: 72 * scale, lineHeight: 1,
      display: 'flex', alignItems: 'center', gap: 14 * scale,
      color: BP.ink, fontWeight: 500,
    }}>
      <span style={{ color: BP.mint, fontWeight: 600 }}>$</span>
      <span style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>beneplus</span>
      <Caret width={18 * scale} height={56 * scale} color={BP.indigo} />
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 04 · Beneplus()   — function call
// ═════════════════════════════════════════════════════════════
function Logo04({ scale = 1, fg = BP.ink }) {
  return (
    <div style={{
      fontFamily: SANS, fontSize: 88 * scale, lineHeight: 1,
      letterSpacing: '-0.045em', display: 'flex', alignItems: 'baseline',
      color: fg, fontWeight: 600,
    }}>
      <span>Beneplus</span>
      <span style={{
        fontFamily: MONO, fontWeight: 400, color: BP.indigo,
        fontSize: 80 * scale, marginLeft: 2 * scale, letterSpacing: '-0.05em',
      }}>(<span style={{ color: BP.amber, fontSize: 60 * scale }}>+</span>)</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 05 · () => Beneplus   — arrow function returning the brand
// ═════════════════════════════════════════════════════════════
function Logo05({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: MONO, fontSize: 56 * scale, lineHeight: 1,
      display: 'flex', alignItems: 'center', gap: 14 * scale,
      color: BP.ink, fontWeight: 500,
    }}>
      <span style={{ color: BP.gray }}>()</span>
      <span style={{ color: BP.violet, fontWeight: 600 }}>=&gt;</span>
      <span style={{
        fontFamily: SANS, fontWeight: 600, fontSize: 72 * scale,
        letterSpacing: '-0.04em', color: BP.ink,
      }}>Beneplus</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 06 · // Beneplus   — code-comment wordmark
// ═════════════════════════════════════════════════════════════
function Logo06({ scale = 1 }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 4 * scale,
    }}>
      <div style={{
        fontFamily: MONO, fontSize: 18 * scale, color: BP.gray,
        letterSpacing: '0.04em',
      }}>// software, built with care</div>
      <div style={{
        fontFamily: MONO, fontSize: 72 * scale, lineHeight: 1,
        display: 'flex', alignItems: 'center', gap: 14 * scale,
        color: BP.ink, fontWeight: 600, letterSpacing: '-0.02em',
      }}>
        <span style={{ color: BP.mint, fontWeight: 500 }}>//</span>
        <span>Beneplus</span>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 07 · {B+}   — brace-monogram tile (syntax-colored)
// ═════════════════════════════════════════════════════════════
function BraceTile({ size = 140, bg = BP.ink, braceColor = BP.violet, letterColor = BP.paper, plusColor = BP.mint }) {
  return (
    <div style={{
      width: size, height: size, background: bg, borderRadius: size * 0.08,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: MONO, fontSize: size * 0.62,
      fontWeight: 700, letterSpacing: '-0.05em', position: 'relative',
      boxShadow: `inset 0 0 0 1px ${BP.gridline}`,
      overflow: 'hidden',
    }}>
      <span style={{ color: braceColor, fontWeight: 400 }}>{'{'}</span>
      <span style={{ color: letterColor, margin: `0 ${size * 0.02}px` }}>B</span>
      <span style={{ color: plusColor, fontSize: size * 0.5, transform: `translateY(${-size * 0.04}px)`, display: 'inline-block' }}>+</span>
      <span style={{ color: braceColor, fontWeight: 400 }}>{'}'}</span>
    </div>
  );
}
function Logo07({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 * scale }}>
      <BraceTile size={140 * scale} />
      <div style={{
        fontFamily: SANS, fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>Beneplus</div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 08 · Terminal window mark — small "ship" window with prompt
// ═════════════════════════════════════════════════════════════
function TerminalWindow({ width = 360, height = 180 }) {
  return (
    <div style={{
      width, height, background: BP.ink, borderRadius: 10,
      overflow: 'hidden', boxShadow: '0 20px 40px -20px rgba(11,16,32,0.55), inset 0 0 0 1px rgba(255,255,255,0.04)',
      fontFamily: MONO, color: BP.paper,
      display: 'flex', flexDirection: 'column',
    }}>
      {/* chrome */}
      <div style={{
        padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 6,
        borderBottom: `1px solid ${BP.gridline}`,
      }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FEBC2E' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C840' }} />
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: BP.gray, letterSpacing: '0.04em' }}>~/beneplus</span>
      </div>
      {/* body */}
      <div style={{
        flex: 1, padding: '18px 18px',
        display: 'flex', flexDirection: 'column', gap: 8,
        fontSize: 16, lineHeight: 1.4,
      }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <span style={{ color: BP.mint }}>$</span>
          <span style={{ color: BP.paper, fontWeight: 500 }}>beneplus</span>
          <span style={{ color: BP.amber }}>--build</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: BP.gray }}>
          <span style={{ color: BP.mint }}>✓</span> shipped in 12ms
          <Caret width={9} height={18} color={BP.indigo} />
        </div>
      </div>
    </div>
  );
}
function Logo08({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 28 * scale }}>
      <TerminalWindow width={300 * scale} height={160 * scale} />
      <div style={{
        fontFamily: SANS, fontSize: 56 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>Beneplus</div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 09 · Beneplus;   — statement wordmark with semicolon accent
// ═════════════════════════════════════════════════════════════
function Logo09({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: SANS, fontSize: 96 * scale, lineHeight: 1,
      letterSpacing: '-0.045em', display: 'flex', alignItems: 'baseline',
      color: BP.ink, fontWeight: 600,
    }}>
      <span>Beneplus</span>
      <span style={{
        color: BP.indigo, fontFamily: MONO, fontWeight: 500,
        marginLeft: 2 * scale, fontSize: 96 * scale,
      }}>;</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 10 · { + }   — symbol-only mark: braces around a plus
// ═════════════════════════════════════════════════════════════
function BracePlus({ size = 130, braceColor = BP.indigo, plusColor = BP.ink }) {
  return (
    <div style={{
      width: size, height: size,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: MONO, gap: size * 0.06,
    }}>
      <span style={{
        color: braceColor, fontSize: size * 1.0, fontWeight: 300,
        lineHeight: 0.85, transform: `translateY(${-size * 0.02}px)`,
      }}>{'{'}</span>
      <PlusGlyph size={size * 0.36} thickness={size * 0.085} color={plusColor} radius={2} />
      <span style={{
        color: braceColor, fontSize: size * 1.0, fontWeight: 300,
        lineHeight: 0.85, transform: `translateY(${-size * 0.02}px)`,
      }}>{'}'}</span>
    </div>
  );
}
function Logo10({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 * scale }}>
      <BracePlus size={130 * scale} braceColor={BP.indigo} plusColor={BP.ink} />
      <div style={{
        fontFamily: SANS, fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>Beneplus</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// App-icon tiles
// ─────────────────────────────────────────────────────────────
function AppTile({ bg, children, radius = 56 }) {
  return (
    <div style={{
      width: 240, height: 240, borderRadius: radius, background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 24px 48px -24px rgba(11,16,32,0.55), 0 2px 4px rgba(11,16,32,0.18)',
      position: 'relative', overflow: 'hidden',
    }}>
      {children}
    </div>
  );
}

function Icon01() { // {B+} tile
  return <AppTile bg={BP.ink}><BraceTile size={170} bg="transparent" /></AppTile>;
}
function Icon02() { // </> fragment glyph
  return (
    <AppTile bg={BP.paper}>
      <div style={{
        fontFamily: MONO, fontSize: 110, fontWeight: 600,
        color: BP.ink, letterSpacing: '-0.05em',
        display: 'flex', alignItems: 'center',
      }}>
        <span style={{ color: BP.gray }}>&lt;/</span>
        <span style={{ color: BP.indigo }}>&gt;</span>
      </div>
    </AppTile>
  );
}
function Icon03() { // terminal prompt $_
  return (
    <AppTile bg={BP.ink}>
      <div style={{
        fontFamily: MONO, fontSize: 110, fontWeight: 600,
        color: BP.paper, display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <span style={{ color: BP.mint }}>$</span>
        <Caret width={20} height={68} color={BP.indigo} />
      </div>
    </AppTile>
  );
}
function Icon04() { // big plus indigo
  return (
    <AppTile bg={BP.indigo}>
      <PlusGlyph size={130} thickness={28} color={BP.paper} radius={4} />
    </AppTile>
  );
}

// ─────────────────────────────────────────────────────────────
// Business card (dev-shop)
// ─────────────────────────────────────────────────────────────
function BizCard({ variant = 'ink' }) {
  const palettes = {
    ink:    { bg: BP.ink,    fg: BP.paper, accent: BP.indigo, sub: BP.gray, grid: BP.gridline, codeStr: BP.mint, codeFn: BP.amber },
    paper:  { bg: BP.paper,  fg: BP.ink,   accent: BP.indigo, sub: BP.gray, grid: BP.paper2, codeStr: '#15803D', codeFn: '#B45309' },
    indigo: { bg: BP.indigo, fg: BP.paper, accent: BP.mint,   sub: '#C7CCFF', grid: '#3D5BE8', codeStr: BP.paper, codeFn: BP.amber },
  };
  const p = palettes[variant];
  return (
    <div style={{
      width: 520, height: 320, background: p.bg, color: p.fg,
      borderRadius: 12, padding: 32, position: 'relative',
      fontFamily: SANS,
      boxShadow: '0 30px 60px -30px rgba(11,16,32,0.55), 0 4px 8px rgba(11,16,32,0.12)',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      overflow: 'hidden',
    }}>
      {/* faint grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${p.grid} 1px, transparent 1px), linear-gradient(90deg, ${p.grid} 1px, transparent 1px)`,
        backgroundSize: '32px 32px', opacity: variant === 'paper' ? 0.55 : 0.25,
        maskImage: 'radial-gradient(ellipse at 90% 110%, black 0%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 90% 110%, black 0%, transparent 70%)',
      }} />
      {/* top: mini brace logo */}
      <div style={{
        fontFamily: MONO, fontSize: 26, fontWeight: 600, letterSpacing: '-0.03em',
        display: 'flex', alignItems: 'center', gap: 4, position: 'relative',
      }}>
        <span style={{ color: p.accent, fontWeight: 400, fontSize: 30 }}>{'{'}</span>
        <span>Beneplus</span>
        <span style={{ color: p.accent, fontWeight: 400, fontSize: 30 }}>{'}'}</span>
      </div>

      {/* contact as code-ish */}
      <div style={{ lineHeight: 1.4, position: 'relative', fontFamily: MONO, fontSize: 13 }}>
        <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em', fontFamily: SANS, color: p.fg }}>Arjun Mehta</div>
        <div style={{ fontSize: 13, color: p.sub, marginTop: 2, fontFamily: SANS }}>Principal Engineer</div>
        <div style={{ marginTop: 16 }}>
          <span style={{ color: p.sub }}>const</span>{' '}
          <span style={{ color: p.codeFn }}>email</span>
          {' = '}
          <span style={{ color: p.codeStr }}>"arjun@beneplus.dev"</span>
        </div>
      </div>

      {/* corner brace */}
      <div style={{
        position: 'absolute', right: 18, bottom: 6,
        fontFamily: MONO, fontSize: 110, color: p.accent, opacity: 0.22, fontWeight: 300, lineHeight: 1,
      }}>{'}'}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Website hero — dev-shop positioning
// ─────────────────────────────────────────────────────────────
function WebHero() {
  return (
    <div style={{
      width: 880, height: 480, background: BP.ink, borderRadius: 14,
      overflow: 'hidden', position: 'relative', color: BP.paper,
      fontFamily: SANS,
      boxShadow: '0 30px 60px -30px rgba(11,16,32,0.6)',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${BP.gridline} 1px, transparent 1px), linear-gradient(90deg, ${BP.gridline} 1px, transparent 1px)`,
        backgroundSize: '40px 40px', opacity: 0.55,
        maskImage: 'radial-gradient(ellipse at 75% 60%, black 30%, transparent 80%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 75% 60%, black 30%, transparent 80%)',
      }} />
      {/* top bar */}
      <div style={{
        position: 'relative',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 32px', borderBottom: `1px solid ${BP.gridline}`,
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 22, fontWeight: 600, letterSpacing: '-0.03em',
          display: 'flex', alignItems: 'center', gap: 3, color: BP.paper,
        }}>
          <span style={{ color: BP.indigo, fontWeight: 400, fontSize: 26 }}>{'{'}</span>
          Beneplus
          <span style={{ color: BP.indigo, fontWeight: 400, fontSize: 26 }}>{'}'}</span>
        </div>
        <div style={{
          display: 'flex', gap: 28, fontSize: 13, color: BP.paper, fontWeight: 500, opacity: 0.85,
          fontFamily: MONO, letterSpacing: '0.02em',
        }}>
          <span>./work</span><span>./services</span><span>./team</span><span>./contact</span>
        </div>
        <div style={{
          padding: '8px 16px', borderRadius: 6, background: BP.indigo, color: BP.paper,
          fontSize: 13, fontWeight: 600, fontFamily: MONO,
        }}>$ start →</div>
      </div>
      {/* hero */}
      <div style={{ position: 'relative', padding: '52px 48px', display: 'flex', gap: 40 }}>
        <div style={{ flex: 1.2 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '5px 10px', borderRadius: 4,
            background: '#FFFFFF08', color: BP.mint,
            fontFamily: MONO,
            fontSize: 11, letterSpacing: '0.06em', fontWeight: 500,
            marginBottom: 18,
            border: `1px solid ${BP.gridline}`,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: BP.mint, boxShadow: `0 0 8px ${BP.mint}` }} />
            // accepting Q3 projects
          </div>
          <h1 style={{
            fontFamily: SANS,
            fontSize: 50, lineHeight: 1.02, fontWeight: 600,
            letterSpacing: '-0.04em', color: BP.paper, margin: 0,
          }}>We build the<br/>software<br/>you ship.</h1>
          <p style={{
            fontSize: 14, color: '#9BA4BD', maxWidth: 360, marginTop: 18, lineHeight: 1.55,
            fontFamily: MONO,
          }}>Beneplus is a development studio for product teams — web, mobile, AI integrations, and the engineers who actually ship.</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 26 }}>
            <div style={{ padding: '12px 20px', borderRadius: 6, background: BP.indigo, color: BP.paper, fontSize: 13, fontWeight: 600, fontFamily: MONO }}>$ book_intro()</div>
            <div style={{ padding: '12px 20px', borderRadius: 6, border: `1px solid ${BP.gridline}`, fontSize: 13, fontWeight: 500, color: BP.paper, fontFamily: MONO }}>./case-studies</div>
          </div>
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <TerminalWindow width={300} height={200} />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  BP, MONO, SANS, Plate, PlusGlyph, Caret,
  Logo01, Logo02, Logo03, Logo04, Logo05, Logo06, Logo07, Logo08, Logo09, Logo10,
  Icon01, Icon02, Icon03, Icon04,
  BraceTile, BracePlus, TerminalWindow, BizCard, WebHero,
});
