// ─────────────────────────────────────────────────────────────
// Beneplus — Brand identity
// ─────────────────────────────────────────────────────────────
// ONE mark. ONE wordmark. ONE accent. Built to last.
//
// Concept: the mark is a rounded square split into a 2×2 grid
// by a thin cream divider — reading as a "+". Three quadrants
// are slate (the foundation: software, craft, team). The top-
// right quadrant is vermillion — the *plus* Beneplus adds.

const C = {
  slate:      '#0B0F1A',   // ink
  slate2:     '#181D2A',   // raised
  slate3:     '#262C3D',   // line
  bone:       '#ECE5D5',   // warm cream
  bone2:      '#D8D1C0',   // bone shade
  vermillion: '#FF4B26',   // accent
  mute:       '#6B6E78',
  paper:      '#F6F1E5',   // softest cream
};

const DISPLAY = '"Hanken Grotesk", system-ui, sans-serif';
const MONO    = '"Geist Mono", "JetBrains Mono", ui-monospace, monospace';

// ─────────────────────────────────────────────────────────────
// The Mark
// ─────────────────────────────────────────────────────────────
function Mark({ size = 240, ground = C.bone, ink = C.slate, accent = C.vermillion, accentPos = 'tr' }) {
  // accentPos = 'tl' | 'tr' | 'bl' | 'br'
  const cells = {
    tl: [accent, ink, ink, ink],
    tr: [ink, accent, ink, ink],
    bl: [ink, ink, accent, ink],
    br: [ink, ink, ink, accent],
  }[accentPos];
  const divider = size * 0.025;   // bone gap
  const pad     = size * 0.025;
  const radius  = size * 0.13;
  const inner   = size * 0.045;
  return (
    <div style={{
      width: size, height: size, borderRadius: radius,
      background: ground,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gridTemplateRows: '1fr 1fr',
      gap: divider,
      padding: pad,
      boxSizing: 'border-box',
      overflow: 'hidden',
    }}>
      {cells.map((c, i) => (
        <div key={i} style={{ background: c, borderRadius: inner }} />
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// The Wordmark
// ─────────────────────────────────────────────────────────────
function Wordmark({ size = 80, color = C.slate, weight = 700, tracking = '-0.04em' }) {
  return (
    <span style={{
      fontFamily: DISPLAY, fontWeight: weight,
      fontSize: size, lineHeight: 1, letterSpacing: tracking,
      color, display: 'inline-block',
    }}>Beneplus</span>
  );
}

// ─────────────────────────────────────────────────────────────
// Primary lockup — mark + wordmark, horizontally
// ─────────────────────────────────────────────────────────────
function Lockup({ size = 80, ground = C.bone, ink = C.slate, accent = C.vermillion }) {
  const markSize = size * 1.15;
  const gap = size * 0.32;
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap }}>
      <Mark size={markSize} ground={ground} ink={ink} accent={accent} />
      <Wordmark size={size} color={ink} />
    </div>
  );
}

// Stacked lockup — mark above wordmark
function StackedLockup({ size = 80, ground = C.bone, ink = C.slate, accent = C.vermillion }) {
  const markSize = size * 1.6;
  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: size * 0.4 }}>
      <Mark size={markSize} ground={ground} ink={ink} accent={accent} />
      <Wordmark size={size} color={ink} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Section wrapper
// ─────────────────────────────────────────────────────────────
function Section({ bg = C.bone, fg = C.slate, children, pad = '120px 80px', minH = 'auto' }) {
  return (
    <section style={{
      background: bg, color: fg,
      padding: pad, minHeight: minH,
      position: 'relative',
      fontFamily: DISPLAY,
    }}>
      <div style={{ maxWidth: 1180, margin: '0 auto', position: 'relative' }}>
        {children}
      </div>
    </section>
  );
}

// Eyebrow label (small mono)
function Eyebrow({ children, color }) {
  return (
    <div style={{
      fontFamily: MONO, fontSize: 12, letterSpacing: '0.16em',
      textTransform: 'uppercase', fontWeight: 500,
      color: color || C.mute, marginBottom: 24,
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <span style={{ width: 16, height: 1, background: 'currentColor', opacity: 0.6 }} />
      {children}
    </div>
  );
}

// Big section title
function SectionTitle({ children, color }) {
  return (
    <h2 style={{
      fontFamily: DISPLAY, fontSize: 56, lineHeight: 1.02,
      fontWeight: 600, letterSpacing: '-0.035em', margin: 0,
      color: color || 'inherit', maxWidth: 880,
    }}>{children}</h2>
  );
}

// Body paragraph
function Body({ children, color, max = 540 }) {
  return (
    <p style={{
      fontFamily: DISPLAY, fontSize: 18, lineHeight: 1.5,
      fontWeight: 400, maxWidth: max,
      color: color || C.mute, margin: 0,
    }}>{children}</p>
  );
}

// ─────────────────────────────────────────────────────────────
// App icons — phone home-screen mockup
// ─────────────────────────────────────────────────────────────
function PhoneHomeScreen() {
  return (
    <div style={{
      width: 300, height: 620, borderRadius: 48,
      background: C.slate, padding: 14,
      boxShadow: '0 50px 100px -40px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.05)',
      position: 'relative',
    }}>
      <div style={{
        width: '100%', height: '100%', borderRadius: 36,
        background: `linear-gradient(180deg, #1A1F2D 0%, #0B0F1A 100%)`,
        position: 'relative', overflow: 'hidden',
        padding: '50px 24px 24px',
      }}>
        {/* status bar */}
        <div style={{
          position: 'absolute', top: 18, left: 24, right: 24,
          display: 'flex', justifyContent: 'space-between',
          fontFamily: DISPLAY, fontSize: 12, fontWeight: 600, color: C.bone,
        }}>
          <span>9:41</span>
          <span style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ width: 14, height: 8, border: `1px solid ${C.bone}`, borderRadius: 2 }} />
          </span>
        </div>
        {/* notch */}
        <div style={{
          position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
          width: 100, height: 28, background: C.slate, borderRadius: 16,
        }} />
        {/* app grid */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 22,
          marginTop: 30,
        }}>
          {[
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['beneplus', 'beneplus'], // highlighted
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
            ['#3A4252', null],
          ].map((tile, i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
              {tile[0] === 'beneplus'
                ? <Mark size={56} ground={C.bone} ink={C.slate} accent={C.vermillion} />
                : <div style={{ width: 56, height: 56, borderRadius: 14, background: tile[0], opacity: 0.7 }} />}
              <span style={{
                fontFamily: DISPLAY, fontSize: 9.5, color: C.bone,
                fontWeight: tile[1] === 'beneplus' ? 600 : 400,
              }}>
                {tile[1] === 'beneplus' ? 'Beneplus' : ''}
              </span>
            </div>
          ))}
        </div>
        {/* dock */}
        <div style={{
          position: 'absolute', left: 14, right: 14, bottom: 20,
          padding: '12px 14px', borderRadius: 26,
          background: 'rgba(255,255,255,0.08)',
          backdropFilter: 'blur(8px)',
          display: 'flex', justifyContent: 'space-around',
        }}>
          {['#3A4252', '#3A4252', 'beneplus', '#3A4252'].map((t, i) => (
            t === 'beneplus'
              ? <Mark key={i} size={48} />
              : <div key={i} style={{ width: 48, height: 48, borderRadius: 11, background: t, opacity: 0.7 }} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Business card — front + back
// ─────────────────────────────────────────────────────────────
function CardFront() {
  return (
    <div style={{
      width: 480, height: 280, borderRadius: 10, padding: 32,
      background: C.slate, color: C.bone,
      boxShadow: '0 40px 80px -40px rgba(0,0,0,0.55), 0 4px 8px rgba(0,0,0,0.15)',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      position: 'relative', overflow: 'hidden',
      fontFamily: DISPLAY,
    }}>
      <Mark size={62} ground={C.slate2} ink={C.bone} accent={C.vermillion} />
      <div>
        <div style={{ fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', color: C.bone }}>Arjun Mehta</div>
        <div style={{ fontSize: 13, color: C.mute, marginTop: 3 }}>Principal Engineer</div>
        <div style={{
          marginTop: 18, fontFamily: MONO, fontSize: 11.5, color: C.bone,
          letterSpacing: '0.02em', lineHeight: 1.6,
        }}>
          arjun@beneplus.dev<br />
          +1 415 555 0117
        </div>
      </div>
      <div style={{
        position: 'absolute', right: -40, top: -40,
        width: 200, height: 200, opacity: 0.6,
      }}>
        <Mark size={200} ground={C.slate} ink={C.slate2} accent={C.vermillion} />
      </div>
    </div>
  );
}
function CardBack() {
  return (
    <div style={{
      width: 480, height: 280, borderRadius: 10, padding: 32,
      background: C.bone, color: C.slate,
      boxShadow: '0 40px 80px -40px rgba(0,0,0,0.45), 0 4px 8px rgba(0,0,0,0.1)',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      position: 'relative', overflow: 'hidden',
      fontFamily: DISPLAY,
    }}>
      <div style={{
        fontFamily: DISPLAY, fontSize: 38, fontWeight: 600, lineHeight: 1.0,
        letterSpacing: '-0.035em', color: C.slate, maxWidth: 380,
      }}>
        Software,<br />built well.
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <Wordmark size={26} />
        <div style={{
          fontFamily: MONO, fontSize: 11, color: C.mute,
          letterSpacing: '0.04em', textAlign: 'right', lineHeight: 1.6,
        }}>
          beneplus.dev<br />Est. 2019
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Website hero
// ─────────────────────────────────────────────────────────────
function SitePreview() {
  return (
    <div style={{
      width: 1080, height: 600, borderRadius: 14,
      background: C.bone, overflow: 'hidden', position: 'relative',
      boxShadow: '0 50px 100px -40px rgba(0,0,0,0.55)',
      fontFamily: DISPLAY,
    }}>
      {/* nav */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '24px 40px',
        borderBottom: `1px solid ${C.slate}18`,
      }}>
        <Lockup size={22} />
        <nav style={{ display: 'flex', gap: 36, fontSize: 14, fontWeight: 500, color: C.slate }}>
          <span>Work</span><span>Services</span><span>Studio</span><span>Journal</span>
        </nav>
        <div style={{
          padding: '10px 18px', borderRadius: 6, background: C.slate, color: C.bone,
          fontSize: 13, fontWeight: 600,
        }}>Start a project</div>
      </div>
      {/* hero */}
      <div style={{ padding: '64px 56px 40px', display: 'flex', gap: 40 }}>
        <div style={{ flex: 1.4 }}>
          <div style={{
            fontFamily: MONO, fontSize: 12, letterSpacing: '0.16em',
            textTransform: 'uppercase', color: C.mute, marginBottom: 22,
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: C.vermillion }} />
            A software studio · est. 2019
          </div>
          <h1 style={{
            fontFamily: DISPLAY, fontSize: 76, lineHeight: 0.98,
            fontWeight: 600, letterSpacing: '-0.04em', color: C.slate, margin: 0,
          }}>
            We build<br />the software<br />you ship.
          </h1>
          <p style={{
            fontFamily: DISPLAY, fontSize: 17, lineHeight: 1.5, color: C.mute,
            maxWidth: 440, marginTop: 26,
          }}>
            Beneplus is a small studio of engineers and product designers. We work with founders and teams who need to ship serious software — quickly, and properly.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 30 }}>
            <div style={{
              padding: '14px 22px', borderRadius: 8, background: C.slate, color: C.bone,
              fontSize: 14, fontWeight: 600,
            }}>Book an intro call →</div>
            <div style={{
              padding: '14px 22px', borderRadius: 8, border: `1px solid ${C.slate}33`,
              color: C.slate, fontSize: 14, fontWeight: 500,
            }}>See selected work</div>
          </div>
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Mark size={260} ground={C.bone} ink={C.slate} accent={C.vermillion} />
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Color swatch
// ─────────────────────────────────────────────────────────────
function Swatch({ color, name, hex, role, border = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{
        width: '100%', aspectRatio: '1 / 1', background: color,
        borderRadius: 12,
        boxShadow: border ? `inset 0 0 0 1px ${C.slate}1A` : 'none',
      }} />
      <div>
        <div style={{ fontFamily: DISPLAY, fontSize: 17, fontWeight: 600, letterSpacing: '-0.01em' }}>{name}</div>
        <div style={{ fontFamily: MONO, fontSize: 12, color: C.mute, marginTop: 2 }}>{hex}</div>
        <div style={{ fontFamily: DISPLAY, fontSize: 13, color: C.mute, marginTop: 8, lineHeight: 1.45 }}>{role}</div>
      </div>
    </div>
  );
}

Object.assign(window, {
  C, DISPLAY, MONO,
  Mark, Wordmark, Lockup, StackedLockup,
  Section, Eyebrow, SectionTitle, Body, Swatch,
  PhoneHomeScreen, CardFront, CardBack, SitePreview,
});
