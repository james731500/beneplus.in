// ─────────────────────────────────────────────────────────────
// Beneplus — Logo directions (IT / technology partner)
// ─────────────────────────────────────────────────────────────
// The "+" is now read as: value-add, positive-sum partnership,
// a node, a join operator. Visuals lean precision/geometry,
// not wellness. Three type families:
//   • Geist        — primary geometric sans (wordmark)
//   • Geist Mono   — terminal / version / technical accents
//   • Space Grotesk— alt geometric for editorial moments
//
// Palette
const BP = {
  ink:     '#0B1020',   // near-black navy
  ink2:    '#141A2E',
  paper:   '#F2F4F8',   // cool off-white
  paper2:  '#E5E8F0',
  indigo:  '#4D5EFF',   // primary electric
  violet:  '#8B5BFF',
  mint:    '#00E1A6',   // signal mint
  cyan:    '#22D3EE',
  amber:   '#FFB020',
  gray:    '#6B7280',
  gridline:'#1E2540',
};

// ─────────────────────────────────────────────────────────────
// Plate — generous padded canvas with a tiny corner label
// ─────────────────────────────────────────────────────────────
function Plate({ bg = BP.paper, fg = BP.ink, note, children, padding = 0, gridded = false }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', overflow: 'hidden', padding,
      fontFamily: 'Geist, system-ui, sans-serif',
    }}>
      {gridded && (
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(${BP.paper2} 1px, transparent 1px), linear-gradient(90deg, ${BP.paper2} 1px, transparent 1px)`,
          backgroundSize: '32px 32px',
          maskImage: 'radial-gradient(ellipse at center, black 40%, transparent 78%)',
          WebkitMaskImage: 'radial-gradient(ellipse at center, black 40%, transparent 78%)',
          opacity: 0.7,
        }} />
      )}
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
      {note && (
        <div style={{
          position: 'absolute', left: 18, bottom: 14, zIndex: 2,
          fontFamily: '"Geist Mono", ui-monospace, monospace',
          fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase',
          opacity: 0.55, fontWeight: 500,
        }}>{note}</div>
      )}
    </div>
  );
}

// Reusable: a clean square-cornered plus glyph
function PlusGlyph({ size = 24, thickness = 6, color = BP.indigo, radius = 0 }) {
  return (
    <span style={{
      display: 'inline-block', position: 'relative',
      width: size, height: size, flexShrink: 0,
    }}>
      <span style={{
        position: 'absolute', left: 0, right: 0, top: '50%',
        height: thickness, transform: 'translateY(-50%)',
        background: color, borderRadius: radius,
      }} />
      <span style={{
        position: 'absolute', top: 0, bottom: 0, left: '50%',
        width: thickness, transform: 'translateX(-50%)',
        background: color, borderRadius: radius,
      }} />
    </span>
  );
}

// ═════════════════════════════════════════════════════════════
// 01 · bene+   ·   lowercase wordmark, electric plus
// ═════════════════════════════════════════════════════════════
function Logo01({ scale = 1, plusColor = BP.indigo, fg = BP.ink }) {
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontWeight: 600, letterSpacing: '-0.05em',
      fontSize: 120 * scale, lineHeight: 1, color: fg,
      display: 'flex', alignItems: 'baseline',
    }}>
      <span>bene</span>
      <PlusGlyph
        size={56 * scale}
        thickness={14 * scale}
        color={plusColor}
        radius={2}
      />
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 02 · Tri-part wordmark   ·   Bene · + · plus
// ═════════════════════════════════════════════════════════════
function Logo02({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontSize: 72 * scale, lineHeight: 1, letterSpacing: '-0.035em',
      display: 'flex', alignItems: 'center', gap: 18 * scale,
      color: BP.ink,
    }}>
      <span style={{ fontWeight: 700 }}>Bene</span>
      <PlusGlyph size={28 * scale} thickness={7 * scale} color={BP.indigo} radius={1} />
      <span style={{ fontWeight: 400, color: BP.gray }}>plus</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 03 · Quadrant plus — four colored squares meeting in a +
//     reads as: four disciplines, one partnership.
// ═════════════════════════════════════════════════════════════
function QuadrantMark({ size = 130, gap = 10, palette }) {
  const p = palette || [BP.ink, BP.indigo, BP.amber, BP.mint];
  const cell = (size - gap) / 2;
  return (
    <div style={{
      width: size, height: size, position: 'relative', display: 'grid',
      gridTemplateColumns: `${cell}px ${cell}px`,
      gridTemplateRows: `${cell}px ${cell}px`,
      gap: gap,
    }}>
      <div style={{ background: p[0], borderRadius: 4 }} />
      <div style={{ background: p[1], borderRadius: 4 }} />
      <div style={{ background: p[2], borderRadius: 4 }} />
      <div style={{ background: p[3], borderRadius: 4 }} />
    </div>
  );
}
function Logo03({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 22 * scale }}>
      <QuadrantMark size={130 * scale} gap={10 * scale} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 04 · Network-node plus mark — 5 dots forming a +,
//     thin connector lines. Reads as: nodes joining.
// ═════════════════════════════════════════════════════════════
function NodeMark({ size = 110, color = BP.ink, accent = BP.indigo, stroke = 2 }) {
  // 5 nodes: center + N/E/S/W
  const r = 7, R = size / 2 - 8;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size}>
      <g stroke={color} strokeWidth={stroke} strokeLinecap="round" fill="none" opacity="0.85">
        <line x1={size/2} y1={size/2 - R} x2={size/2} y2={size/2 + R} />
        <line x1={size/2 - R} y1={size/2} x2={size/2 + R} y2={size/2} />
      </g>
      {/* outer nodes */}
      {[
        [size/2, size/2 - R],
        [size/2 + R, size/2],
        [size/2, size/2 + R],
        [size/2 - R, size/2],
      ].map(([x,y], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill={color} />
      ))}
      {/* center node = accent */}
      <circle cx={size/2} cy={size/2} r={r + 2} fill={accent} />
    </svg>
  );
}
function Logo04({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 22 * scale }}>
      <NodeMark size={120 * scale} color={BP.ink} accent={BP.indigo} stroke={2.5 * scale} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 05 · Terminal / JSX wordmark   ·   <bene+ />
// ═════════════════════════════════════════════════════════════
function Logo05({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: '"Geist Mono", ui-monospace, monospace',
      fontSize: 60 * scale, lineHeight: 1,
      display: 'flex', alignItems: 'center', gap: 4 * scale,
      color: BP.ink, fontWeight: 500, letterSpacing: '-0.02em',
    }}>
      <span style={{ color: BP.gray, fontWeight: 400 }}>&lt;</span>
      <span style={{ fontWeight: 600 }}>bene</span>
      <span style={{ color: BP.indigo, fontWeight: 600 }}>+</span>
      <span style={{ marginLeft: 8 * scale, color: BP.gray, fontWeight: 400 }}>/&gt;</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 06 · Isometric plus block — dimensional, structural
// ═════════════════════════════════════════════════════════════
function IsoPlus({ size = 140, light = BP.indigo, mid = '#3D4EE0', dark = '#2A3AB8' }) {
  // Drawn in SVG using parallelograms to fake an isometric extruded plus
  return (
    <svg viewBox="-100 -100 200 200" width={size} height={size}>
      <g transform="rotate(0)">
        {/* shadow blob */}
        <ellipse cx="6" cy="78" rx="68" ry="10" fill={BP.ink} opacity="0.12" />
        {/* Plus footprint = the 5 squares pattern but rendered as 3 stacked rhombi for an iso look.
            Approach: draw three "bars" with top/side/face faces. */}
        {/* Vertical bar */}
        <g>
          {/* top face */}
          <polygon points="-18,-58 18,-58 36,-42 0,-42 -36,-42" fill={light} />
          {/* left face */}
          <polygon points="-18,-58 -18,42 -36,58 -36,-42" fill={dark} />
          {/* right face */}
          <polygon points="18,-58 18,42 36,58 36,-42" fill={mid} />
          {/* front face */}
          <polygon points="-18,42 18,42 36,58 -36,58" fill={mid} />
        </g>
        {/* Horizontal bar (drawn on top so the join looks clean) */}
        <g>
          <polygon points="-58,-18 58,-18 76,-2 -76,-2" fill={light} />
          <polygon points="58,-18 58,18 76,34 76,-2" fill={mid} />
          <polygon points="-58,-18 -58,18 -76,34 -76,-2" fill={dark} />
          <polygon points="-58,18 58,18 76,34 -76,34" fill={mid} />
        </g>
        {/* Center cap on top to clean intersection */}
        <polygon points="-18,-18 18,-18 36,-2 0,-2 -36,-2" fill={light} opacity="0" />
      </g>
    </svg>
  );
}
function Logo06({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 * scale }}>
      <IsoPlus size={130 * scale} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 07 · Tessellated plus — a big + made of small + glyphs.
//     Reads as: systems built from systems.
// ═════════════════════════════════════════════════════════════
function TessellatedPlus({ size = 140, color = BP.ink, accent = BP.indigo }) {
  // 7×7 grid with plus-shaped on/off mask
  const N = 7;
  // mask: which cells are filled to form a big +
  // A 7x7 with center column + center row filled
  const isOn = (r, c) => {
    const mid = 3;
    return r === mid || c === mid;
  };
  const isCenter = (r, c) => r === 3 && c === 3;
  const cell = size / N;
  const sub = cell * 0.7;
  const thick = cell * 0.18;
  return (
    <div style={{
      width: size, height: size,
      display: 'grid',
      gridTemplateColumns: `repeat(${N}, ${cell}px)`,
      gridTemplateRows: `repeat(${N}, ${cell}px)`,
    }}>
      {Array.from({ length: N * N }).map((_, i) => {
        const r = Math.floor(i / N), c = i % N;
        if (!isOn(r, c)) return <div key={i} />;
        const col = isCenter(r, c) ? accent : color;
        return (
          <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <PlusGlyph size={sub} thickness={thick} color={col} radius={1} />
          </div>
        );
      })}
    </div>
  );
}
function Logo07({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 22 * scale }}>
      <TessellatedPlus size={140 * scale} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 08 · Plus-as-letter (the 's' becomes a +)
// ═════════════════════════════════════════════════════════════
function Logo08({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontWeight: 700, letterSpacing: '-0.05em',
      fontSize: 96 * scale, color: BP.ink, lineHeight: 1,
      display: 'flex', alignItems: 'center',
    }}>
      <span>Beneplu</span>
      <span style={{ display: 'inline-block', marginLeft: 6 * scale, transform: `translateY(${2 * scale}px)` }}>
        <PlusGlyph
          size={64 * scale}
          thickness={14 * scale}
          color={BP.indigo}
          radius={2}
        />
      </span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 09 · Versioned wordmark — Beneplus with a vN.0 build chip
// ═════════════════════════════════════════════════════════════
function Logo09({ scale = 1 }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 16 * scale,
    }}>
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 72 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6 * scale,
        padding: `${6*scale}px ${10*scale}px`,
        borderRadius: 999, background: BP.ink, color: BP.mint,
        fontFamily: '"Geist Mono", ui-monospace, monospace',
        fontSize: 13 * scale, fontWeight: 500, letterSpacing: '0.04em',
      }}>
        <span style={{
          width: 6 * scale, height: 6 * scale, borderRadius: '50%',
          background: BP.mint, boxShadow: `0 0 ${10*scale}px ${BP.mint}`,
        }} />
        IT · PARTNER
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 10 · Bracketed minimal — [ beneplus ] · CLI feel
// ═════════════════════════════════════════════════════════════
function Logo10({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: '"Geist Mono", ui-monospace, monospace',
      fontSize: 56 * scale, lineHeight: 1,
      display: 'flex', alignItems: 'center', gap: 12 * scale,
      color: BP.ink, fontWeight: 500, letterSpacing: '-0.01em',
    }}>
      <span style={{ color: BP.indigo, fontWeight: 400 }}>[</span>
      <span style={{ fontWeight: 600 }}>bene</span>
      <PlusGlyph size={22 * scale} thickness={5 * scale} color={BP.indigo} radius={1} />
      <span style={{ fontWeight: 600 }}>plus</span>
      <span style={{ color: BP.indigo, fontWeight: 400 }}>]</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 11 · Cursor wordmark — beneplus with a blinking block caret
// ═════════════════════════════════════════════════════════════
function Logo11({ scale = 1 }) {
  return (
    <div style={{
      fontFamily: 'Geist, system-ui, sans-serif',
      fontSize: 84 * scale, lineHeight: 1, fontWeight: 600,
      letterSpacing: '-0.045em', color: BP.ink,
      display: 'flex', alignItems: 'center', gap: 6 * scale,
    }}>
      <style>{`
        @keyframes bp-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0.15; } }
      `}</style>
      <span>beneplus</span>
      <span style={{
        display: 'inline-block',
        width: 22 * scale, height: 64 * scale,
        background: BP.indigo,
        marginLeft: 4 * scale,
        animation: 'bp-blink 1.05s steps(1, end) infinite',
        transform: `translateY(${2 * scale}px)`,
      }} />
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// 12 · Ribbon plus — a single ribbon path folded into a +
//      Light/shadow reads as a continuous, dimensional mark.
// ═════════════════════════════════════════════════════════════
function RibbonPlus({ size = 130, light = BP.indigo, shade = '#2A3AB8' }) {
  // Two interlocking rounded ribbons. The "underneath" segments
  // are darker to fake folding.
  return (
    <svg viewBox="-100 -100 200 200" width={size} height={size}>
      {/* Horizontal ribbon (back) */}
      <rect x="-86" y="-26" width="172" height="52" rx="14" fill={shade} />
      {/* Vertical ribbon (front) */}
      <rect x="-26" y="-86" width="52" height="172" rx="14" fill={light} />
      {/* Fold highlights where vertical crosses horizontal */}
      <rect x="-26" y="-26" width="52" height="52" fill={light} />
      {/* Subtle ribbon notch shadows on top edge of horizontal where vertical begins */}
      <rect x="-26" y="-26" width="52" height="6" fill={shade} opacity="0.22" />
      <rect x="-26" y="20" width="52" height="6" fill={shade} opacity="0.22" />
    </svg>
  );
}
function Logo12({ scale = 1 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 * scale }}>
      <RibbonPlus size={130 * scale} />
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 60 * scale, fontWeight: 600,
        letterSpacing: '-0.04em', color: BP.ink, lineHeight: 1,
      }}>
        Beneplus
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// App-icon tiles
// ─────────────────────────────────────────────────────────────
function AppTile({ bg, children, radius = 56 }) {
  return (
    <div style={{
      width: 240, height: 240, borderRadius: radius, background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 24px 48px -24px rgba(11,16,32,0.55), 0 2px 4px rgba(11,16,32,0.18)',
      position: 'relative', overflow: 'hidden',
    }}>
      {children}
    </div>
  );
}
function Icon01() { // bene+ on paper
  return (
    <AppTile bg={BP.paper}>
      <div style={{
        fontFamily: 'Geist, system-ui, sans-serif',
        fontWeight: 600, letterSpacing: '-0.05em',
        fontSize: 130, color: BP.ink, lineHeight: 1,
        display: 'flex', alignItems: 'baseline',
      }}>
        b<PlusGlyph size={60} thickness={15} color={BP.indigo} radius={2} />
      </div>
    </AppTile>
  );
}
function Icon02() { // quadrant tile
  return (
    <AppTile bg={BP.paper}>
      <QuadrantMark size={160} gap={14} />
    </AppTile>
  );
}
function Icon03() { // network mark on paper
  return (
    <AppTile bg={BP.paper}>
      <NodeMark size={150} color={BP.ink} accent={BP.indigo} stroke={3} />
    </AppTile>
  );
}
function Icon04() { // big plus on indigo
  return (
    <AppTile bg={BP.indigo}>
      <PlusGlyph size={130} thickness={28} color={BP.paper} radius={4} />
    </AppTile>
  );
}

// ─────────────────────────────────────────────────────────────
// Business card lockup
// ─────────────────────────────────────────────────────────────
function BizCard({ variant = 'ink' }) {
  const palettes = {
    ink:    { bg: BP.ink,    fg: BP.paper, accent: BP.indigo, sub: BP.gray, grid: BP.gridline },
    paper:  { bg: BP.paper,  fg: BP.ink,   accent: BP.indigo, sub: BP.gray, grid: BP.paper2 },
    indigo: { bg: BP.indigo, fg: BP.paper, accent: BP.mint,   sub: '#C7CCFF', grid: '#3D4EE0' },
  };
  const p = palettes[variant];
  return (
    <div style={{
      width: 520, height: 320, background: p.bg, color: p.fg,
      borderRadius: 14, padding: 36, position: 'relative',
      fontFamily: 'Geist, system-ui, sans-serif',
      boxShadow: '0 30px 60px -30px rgba(11,16,32,0.55), 0 4px 8px rgba(11,16,32,0.12)',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      overflow: 'hidden',
    }}>
      {/* grid bg */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${p.grid} 1px, transparent 1px), linear-gradient(90deg, ${p.grid} 1px, transparent 1px)`,
        backgroundSize: '32px 32px', opacity: variant === 'paper' ? 0.6 : 0.3,
        maskImage: 'radial-gradient(ellipse at 80% 110%, black 0%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 80% 110%, black 0%, transparent 70%)',
      }} />
      {/* top: mini logo */}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 2, position: 'relative',
        fontFamily: 'Geist, system-ui, sans-serif',
        fontSize: 32, fontWeight: 600, letterSpacing: '-0.05em',
      }}>
        bene<PlusGlyph size={16} thickness={4} color={p.accent} radius={1} />
      </div>

      {/* contact */}
      <div style={{ lineHeight: 1.4, position: 'relative' }}>
        <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>Arjun Mehta</div>
        <div style={{ fontSize: 13, color: p.sub, marginTop: 2 }}>Principal Solutions Architect</div>
        <div style={{
          fontSize: 11, color: p.sub, marginTop: 14, letterSpacing: '0.04em',
          fontFamily: '"Geist Mono", ui-monospace, monospace',
        }}>
          arjun@beneplus.io · +1 415 555 0117
        </div>
      </div>

      {/* corner plus */}
      <div style={{
        position: 'absolute', right: -10, bottom: -10,
      }}>
        <PlusGlyph size={120} thickness={18} color={p.accent} radius={2} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Website hero (IT partner positioning)
// ─────────────────────────────────────────────────────────────
function WebHero() {
  return (
    <div style={{
      width: 880, height: 480, background: BP.ink, borderRadius: 14,
      overflow: 'hidden', position: 'relative', color: BP.paper,
      fontFamily: 'Geist, system-ui, sans-serif',
      boxShadow: '0 30px 60px -30px rgba(11,16,32,0.6)',
    }}>
      {/* grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${BP.gridline} 1px, transparent 1px), linear-gradient(90deg, ${BP.gridline} 1px, transparent 1px)`,
        backgroundSize: '40px 40px', opacity: 0.55,
        maskImage: 'radial-gradient(ellipse at 70% 60%, black 30%, transparent 80%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 70% 60%, black 30%, transparent 80%)',
      }} />
      {/* top bar */}
      <div style={{
        position: 'relative',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 32px', borderBottom: `1px solid ${BP.gridline}`,
      }}>
        <div style={{
          fontFamily: 'Geist, system-ui, sans-serif',
          fontSize: 24, fontWeight: 600, letterSpacing: '-0.04em',
          display: 'flex', alignItems: 'baseline', color: BP.paper,
        }}>
          bene<PlusGlyph size={12} thickness={3} color={BP.indigo} radius={1} />
        </div>
        <div style={{
          display: 'flex', gap: 28, fontSize: 13, color: BP.paper, fontWeight: 500, opacity: 0.85,
        }}>
          <span>Services</span><span>Industries</span><span>Case studies</span><span>Careers</span>
        </div>
        <div style={{
          padding: '8px 16px', borderRadius: 6, background: BP.indigo, color: BP.paper,
          fontSize: 13, fontWeight: 600,
        }}>Start a project →</div>
      </div>
      {/* hero */}
      <div style={{ position: 'relative', padding: '56px 48px', display: 'flex', gap: 48 }}>
        <div style={{ flex: 1.2 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 999,
            background: '#FFFFFF10', color: BP.mint,
            fontFamily: '"Geist Mono", monospace',
            fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 500,
            marginBottom: 18,
            border: `1px solid ${BP.gridline}`,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: BP.mint, boxShadow: `0 0 8px ${BP.mint}` }} />
            IT · partner · since 2019
          </div>
          <h1 style={{
            fontFamily: 'Geist, sans-serif',
            fontSize: 54, lineHeight: 1.02, fontWeight: 600,
            letterSpacing: '-0.04em', color: BP.paper, margin: 0,
          }}>Engineering teams,<br/>on demand.</h1>
          <p style={{
            fontSize: 15, color: '#9BA4BD', maxWidth: 380, marginTop: 18, lineHeight: 1.55,
          }}>Beneplus is a technology partner for product teams — cloud, platform, AI integration, and the engineers who actually ship it.</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 26 }}>
            <div style={{ padding: '12px 22px', borderRadius: 6, background: BP.indigo, color: BP.paper, fontSize: 14, fontWeight: 600 }}>Book intro call</div>
            <div style={{ padding: '12px 22px', borderRadius: 6, border: `1px solid ${BP.gridline}`, fontSize: 14, fontWeight: 500, color: BP.paper }}>How we work →</div>
          </div>
        </div>
        <div style={{
          flex: 1, background: '#0E1430', borderRadius: 10, position: 'relative',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          border: `1px solid ${BP.gridline}`,
        }}>
          <NodeMark size={200} color={BP.paper} accent={BP.indigo} stroke={2.5} />
          <div style={{
            position: 'absolute', left: 18, bottom: 14, color: BP.mint, opacity: 0.9,
            fontFamily: '"Geist Mono", monospace',
            fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 500,
          }}>nodes ⋅ joined ⋅ shipping</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  BP, Plate, PlusGlyph,
  Logo01, Logo02, Logo03, Logo04, Logo05, Logo06, Logo07, Logo08, Logo09,
  Logo10, Logo11, Logo12,
  Icon01, Icon02, Icon03, Icon04,
  NodeMark, IsoPlus, QuadrantMark, TessellatedPlus, RibbonPlus,
  BizCard, WebHero,
});
